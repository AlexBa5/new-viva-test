<template>
  <div id="app">
    <div class="page-header">
      <router-link to="/">
        <img alt="logo" src="./assets/logo.png" class="page-logo">
      </router-link>
      <span>New Viva | Тестовое задание</span>
      <router-link to="/admin" class="admin-link">🔐</router-link>
    </div>
    <div class="submenu" v-if="this.$store.getters.auth.isAuthenticated">
      <router-link to="/">Главная</router-link>
      <router-link to="/users">Пользователи</router-link>
      <router-link to="/posts">Посты</router-link>
      <a href="javascript:;" v-on:click="logout()">Выйти</a>
    </div>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'App',
  components: {},
  data: () => ({
  }),
  methods: {
    logout: function () {
      this.$auth.destroyToken();
      this.$router.push('/')
    },
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
  max-width: 600px;
  margin: auto;
}

.page-logo{
  height: 40px;
}

.page-header{
  display: flex;
  align-items: center;
  border-bottom: 1px solid #f1f1f1;
  margin-bottom: 20px;
  padding-bottom: 10px;
  padding-top: 10px;
}

.admin-link{
  text-align: right;
  flex: auto;
}

a{
  text-decoration: none;
}

body {
  margin: 0;
  padding: 0;
}

.submenu { 
  margin-top: -10px;
  margin-bottom: 15px;
  text-align: left;
  border-bottom: 1px solid #f1f1f1;
  padding-bottom: 10px;
}

.submenu a {
  padding: 10px;
}

.actions a {
  padding: 10px;
}
</style>
