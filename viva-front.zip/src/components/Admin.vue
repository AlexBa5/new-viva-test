<template>
    <div class="guarded">
        <div v-if="this.$store.getters.auth.isAuthenticated">
            <p align="center"><img src="https://res.cloudinary.com/dtfbvvkyp/image/upload/v1566331377/laravel-logolockup-cmyk-red.svg" width="400"></p>

            <p align="center">
            <a href="https://travis-ci.org/laravel/framework"><img src="https://travis-ci.org/laravel/framework.svg" alt="Build Status"></a>
            <a href="https://packagist.org/packages/laravel/framework"><img src="https://poser.pugx.org/laravel/framework/d/total.svg" alt="Total Downloads"></a>
            <a href="https://packagist.org/packages/laravel/framework"><img src="https://poser.pugx.org/laravel/framework/v/stable.svg" alt="Latest Stable Version"></a>
            <a href="https://packagist.org/packages/laravel/framework"><img src="https://poser.pugx.org/laravel/framework/license.svg" alt="License"></a>
            </p>

            ## Routes

            <p>POST /api/register</p>
            <p>POST /api/login</p>
            <br>
            <p>GET	/api/posts</p>
            <p>GET	/api/posts/create</p>
            <p>POST /api/posts</p>
            <p>GET	/api/posts/{post}</p>
            <p>GET	/api/posts/{post}/edit</p>
            <p>PUT /api/posts/{post}</p>
            <p>DELETE /api/posts/{post}</p>
            <br>
            <p>GET	/api/users</p>
            <p>GET	/api/users/create</p>
            <p>POST /api/users</p>
            <p>GET	/api/users/{user}</p>
            <p>GET	/api/users/{user}/edit</p>
            <p>PUT /api/users/{user}</p>
            <p>DELETE /api/users/{user}</p>
            <br>

            ## License

            The Laravel framework is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).
        </div>
        <div v-else>
            <Login></Login>
        </div>
    </div>
</template>

<script>
import Login from './Login'

export default {
    name: 'Admin',
    components: {
        Login
    },
    data: () => ({
        users: [],
        posts: [],
    }),
    methods: {
        getUsers: function () {
            this.axios.get('http://new-viva-test/api/users', {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${ localStorage.getItem('accessToken') }`
                }
            }
            ).then((response) => {
                this.users = response.data.data
            })
        },
        getPosts: function () {
            this.axios.get('http://new-viva-test/api/posts', {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${ localStorage.getItem('accessToken') }`
                }
            }
            ).then((response) => {
                this.posts = response.data.data
            })
        },
        createRender() {
            this.getUsers()
            this.getPosts()
        }
    },
    computed: {
        applicationAuth: function () {
            return this.$store.getters.auth.isAuthenticated
        }
    },
    watch: {
        applicationAuth(newVal) {
            if(newVal === true) this.createRender()
        }
    },
    mounted() {
        if (this.$auth.isAuthenticated()) this.createRender()
    }
}
</script>

<style scoped>
    table {
        width: 100%;
        text-align: left;
        padding: 5px;
    }
</style>
