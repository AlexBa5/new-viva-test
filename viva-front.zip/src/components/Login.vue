<template>
        <div class="forms">
            <div>
                {{ message }}
            </div>
            <div class="login br-l">
                <h2>Вход</h2>
                <div class="mb-2">
                    <input type="text" v-model="lemail" placeholder="Email">
                </div>
                <div class="mb-2">
                    <input type="password" v-model="lpassword" placeholder="Пароль">
                </div>
                <button type="submit" v-on:click="login()">Вход</button>
            </div>
            <div class="login">
                <h2>Регистрация</h2>
                <div class="mb-2">
                    <input type="text" v-model="name" placeholder="Имя">
                </div>
                <div class="mb-2">
                    <input type="text" v-model="email" placeholder="Email">
                </div>
                <div class="mb-2">
                    <input type="password" v-model="password" placeholder="Пароль">
                </div>
                <div class="mb-2">
                    <input type="password" v-model="spassword" placeholder="Повторите пароль">
                </div>
                <button type="submit" v-on:click="register()">Регистрация</button>
            </div>
        </div>
</template>

<script>
export default {
    name: 'Login',
    data: () => ({
        message: '',
        name: '',
        spassword: '',
        email: '',
        password: '',
        lemail: '',
        lpassword: ''
    }),
    methods: {
        login: function () {
            if (this.lemail.length < 1 && this.lpassword.length < 1) {
                return;
            }

            let data = {
                email: this.lemail,
                password: this.lpassword
            }
            this.axios.post('http://new-viva-test/api/login', JSON.stringify(data), {
                headers: {
                    'Content-Type': 'application/json'
                }
            }
            ).then((response) => {
                this.message = response.data.message
                this.lemail = ''
                this.lpassword = ''

                localStorage.removeItem('accessToken')
                localStorage.setItem('accessToken', response.data.data.token)
                this.$auth.setToken(response.data.data.token, new Date(Date.now() + 1 * 24*3600*1000))
            }).catch((error) => {
                this.message = error
            })
        },
        register: function () {
            if (this.email.length < 1 && this.password.length < 1 && this.spassword.length < 1 && this.name.length < 1) {
                return;
            }
            
            let data = {
                email: this.email,
                name: this.name,
                password: this.password,
                spassword: this.spassword
            }
            this.axios.post('http://new-viva-test/api/register', JSON.stringify(data), {
                headers: {
                    'Content-Type': 'application/json'
                }
            }
            ).then((response) => {
                this.message = response.data.message
                this.email = ''
                this.name = ''
                this.password = ''
                this.spassword = ''
                
                localStorage.removeItem('accessToken')
                localStorage.setItem('accessToken', response.data.data.token)
                this.$auth.setToken(response.data.data.token, new Date(Date.now() + 1 * 24*3600*1000))
            }).catch((error) => {
                this.message = error
            })
        },
    }
}
</script>

<style scoped>
    .login{
        width: 50%;
        display: inline-block;
    }

    .br-l {
        width: calc(50% - 1px);
        border-right: 1px solid #f1f1f1;
    }
    .mb-2 {
        margin-bottom: 5px;
    }
</style>
