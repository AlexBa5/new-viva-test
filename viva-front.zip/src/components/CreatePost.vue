<template>
  <div class="posts__wrapper single-post">
    <div class="post" v-if="this.$store.getters.auth.isAuthenticated">
        <div>
          <textarea class="editor fs-h1" v-model="post.title"></textarea>
        </div>

        <div>
          <textarea class="editor fs-p" v-model="post.content"></textarea>
        </div>

        <button v-if="this.$store.getters.auth.isAuthenticated" class="cursor-pointer" v-on:click="createPost({title: post.title, content: post.content})">Сохранить</button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Post',
  data: () => ({
    post: []
  }),
  methods: {
    createPost: function (data) {
      this.axios.post(`http://new-viva-test/api/posts`, JSON.stringify(data), {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${ localStorage.getItem('accessToken') }`
        }
      })
      .then(() => {
        this.$router.push('/posts')
      })
    }
  }
}
</script>

<style>
    .post{
        padding: 15px;
        margin: 15px 0;
        border-radius: 4px;
        background: #f7f7f7;
        transition: 0.2s;
        text-align: left;
    }

    .post:hover {
        background: #f3f3f3;
    }

    .post .title {
        font-weight: 200;
        margin: 0;
        font-size: 30px;
        text-decoration: none;
        color: black;
    }

    .text-right{
        text-align: right;
    }

    .cursor-pointer {
      cursor: pointer;
    }

    .text-left {
        text-align: left;
    }

    .editor {
      width: 100%;
      height: auto;
      resize: none;
      border-radius: 4px;
      border: transparent;
      font-family: sans-serif;
      box-sizing: border-box;
      padding: 10px;
    }

    .fs-h1 {
      font-size: 20px;
      min-height: 90px;
    }

    .fs-p{
      min-height: 490px;
    }
</style>