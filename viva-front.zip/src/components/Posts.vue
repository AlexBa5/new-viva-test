<template>
    <div class="guarded">
        <div v-if="this.$store.getters.auth.isAuthenticated">
            <table class="users">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Заголовок</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(post, i) in posts" :key="i">
                        <td>#{{ post.id }}</td>
                        <td><small>{{ post.title }}</small></td>
                        <td class="actions">
                            <router-link :to="`/posts/${post.id}`">✎</router-link>
                            <a v-on:click="deletePost(post.id)" href="javascript:;">🗑</a>
                        </td>
                    </tr>
                </tbody>
            </table>
            <div>
                <router-link to="/posts/create">Добавить</router-link>
            </div>
        </div>
        <div v-else>
            <Login></Login>
        </div>
    </div>
</template>

<script>
import Login from './Login'

export default {
    name: 'Posts',
    components: {
        Login
    },
    data: () => ({
        posts: [],
    }),
    methods: {
        getPosts: function () {
            this.axios.get('http://new-viva-test/api/posts', {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${ localStorage.getItem('accessToken') }`
                }
            }
            ).then((response) => {
                this.posts = response.data.data
            })
        },
        deletePost: function (id) {
            if(id.length < 1) return

            this.axios.delete(`http://new-viva-test/api/posts/${ id }`, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${ localStorage.getItem('accessToken') }`
                }
            }
            ).then(() => {
                this.getPosts()
            })
        },
        createRender() {
            this.getPosts()
        }
    },
    computed: {
        applicationAuth: function () {
            return this.$store.getters.auth.isAuthenticated
        }
    },
    watch: {
        applicationAuth(newVal) {
            if(newVal === true) this.createRender()
        }
    },
    mounted() {
        if (this.$auth.isAuthenticated()) this.createRender()
    }
}
</script>

<style scoped>
    table {
        width: 100%;
        text-align: left;
        padding: 5px;
    }
</style>
