<template>
    <div class="guarded">
        <div v-if="this.$store.getters.auth.isAuthenticated">
            <table class="users">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Имя</th>
                        <th>Email</th>
                        <th>Создан</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(user, i) in users" :key="i">
                        <td>#{{ user.id }}</td>
                        <td>{{ user.name }}</td>
                        <td>{{ user.email }}</td>
                        <td>{{ user.created_at }}</td>
                        <td class="actions">
                            <router-link :to="`/users/${user.id}`">✎</router-link>
                            <a v-on:click="deleteUser(user.id)" href="javascript:;">🗑</a>
                        </td>
                    </tr>
                </tbody>
            </table>
            <div>
                <router-link to="/users/create">Добавить</router-link>
            </div>
        </div>
        <div v-else>
            <Login></Login>
        </div>
    </div>
</template>

<script>
import Login from './Login'

export default {
    name: 'User',
    components: {
        Login
    },
    data: () => ({
        users: [],
    }),
    methods: {
        getUsers: function () {
            this.axios.get('http://new-viva-test/api/users', {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${ localStorage.getItem('accessToken') }`
                }
            }
            ).then((response) => {
                this.users = response.data.data
            })
        },
        deleteUser: function (id) {
            if(id.length < 1) return

            this.axios.delete(`http://new-viva-test/api/users/${ id }`, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${ localStorage.getItem('accessToken') }`
                }
            }
            ).then(() => {
                this.getUsers()
            })
        },
        createRender() {
            this.getUsers()
        }
    },
    computed: {
        applicationAuth: function () {
            return this.$store.getters.auth.isAuthenticated
        }
    },
    watch: {
        applicationAuth(newVal) {
            if(newVal === true) this.createRender()
        }
    },
    mounted() {
        if (this.$auth.isAuthenticated()) this.createRender()
    }
}
</script>

<style scoped>
    table {
        width: 100%;
        text-align: left;
        padding: 5px;
    }
</style>
