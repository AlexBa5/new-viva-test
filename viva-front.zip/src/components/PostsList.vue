<template>
  <div class="posts__wrapper">
    <div class="post" v-for="(post, index) in items" :key="index">
        <router-link :to="`/posts/${post.id}`">
        <h1 class="title">{{ post.title }}</h1>
        <div class="text-right">
            <span>от {{ post.created_at }}</span>
        </div>
        </router-link>
    </div>
  </div>
</template>

<script>
export default {
  name: 'PostsList',
  data: () => ({
    items: []
  }),
  methods: {
    getPosts: function () {
      this.axios.get('http://new-viva-test/api/posts')
      .then((response) => {
        this.items = response.data.data
      })
    }
  },
  mounted() {
    this.getPosts()
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
    .post{
        padding: 15px;
        margin: 15px 0;
        border-radius: 4px;
        background: #f7f7f7;
        transition: 0.2s;
        text-align: left;
    }

    .post:hover {
        background: #f3f3f3;
    }

    .post .title {
        font-weight: 200;
        margin: 0;
        font-size: 20px;
        text-decoration: none;
        color: black;
    }

    .text-right{
        text-align: right;
    }
</style>
