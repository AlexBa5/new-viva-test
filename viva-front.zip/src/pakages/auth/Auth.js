import store from '../../store/index'

const Auth = {
    install(Vue) {
        Vue.prototype.$auth = {
            getToken () {
                let token = store.getters.auth.token 
                let expiration = store.getters.auth.expiration 

                if(token === null || expiration === null) {
                    if(localStorage.getItem('token') === null && localStorage.getItem('expiration') === null) {
                        return null 
                    } else {
                        store.dispatch('setAuth', {
                            token: localStorage.getItem('token'), 
                            isAuthenticated: true, 
                            expiration: localStorage.getItem('expiration')
                        })
                    }
                }
        
                if(!token || !expiration) return null
                
                if(Date.now() > parseInt(expiration)) {
                    Vue.prototype.$auth.destroyToken()
                    return null
                } else {
                    return token
                }
            },    
            setToken (token, expiration) {
                localStorage.setItem('token', token)
                localStorage.setItem('expiration', expiration)

                store.dispatch('setAuth', {
                    token: localStorage.getItem('token'), 
                    isAuthenticated: true, 
                    expiration: localStorage.getItem('expiration')
                })
            },    
            destroyToken () {
                localStorage.removeItem('token')
                localStorage.removeItem('expiration')
                
                store.dispatch('setAuth', {
                    token: null, 
                    isAuthenticated: false, 
                    expiration: null
                })
            },    
            isAuthenticated () {
                if(Vue.prototype.$auth.getToken()) return true
                else return false
            }
        }
    }
}
  
export default Auth