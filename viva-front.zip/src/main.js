import Vue from 'vue'
import App from './App.vue'

import axios from 'axios'
import VueAxios from 'vue-axios'
import VueRouter from 'vue-router'
import store from './store'

import Auth from './pakages/auth/Auth'

Vue.use(VueRouter)
Vue.use(VueAxios, axios)
Vue.use(Auth)

const routes = [
  { path: '/', component: () => import("@/components/PostsList.vue") },
  { path: '/admin', component: () => import("@/components/Admin.vue") },
  { path: '/users', component: () => import("@/components/Users.vue") },
  { path: '/users/create', component: () => import("@/components/CreateUser.vue") },
  { path: '/users/:id', component: () => import("@/components/EditUser.vue") },
  { path: '/posts/create', component: () => import("@/components/CreatePost.vue") },
  { path: '/posts/:id', component: () => import("@/components/Post.vue") },
  { path: '/posts', component: () => import("@/components/Posts.vue") },
]

const router = new VueRouter({
  routes
})

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App),
}).$mount('#app')
