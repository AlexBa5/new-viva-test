import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex)

const store = new Vuex.Store({
	state: {
		auth: {
			token: null,
			isAuthenticated: false
		}
	},
	getters: {
		auth: (state) => {
			return state.auth;
		}
	},
	mutations: {
		mutateAuth: (state, payload) => {
			state.auth = payload;
		}
	},
	actions: {
		setAuth: (context, payload) => {
			context.commit('mutateAuth', payload);
		}
	}
})

export default store;